# How to run the code
- run `make` to get executable file `linker`
- run `./runit.sh` and `./gradeit.sh`